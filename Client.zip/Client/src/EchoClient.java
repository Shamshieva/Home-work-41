import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * @author Burulai Urbaeva
 */
public class EchoClient {
    private final int port;
    private final String host;

    public EchoClient(int port, String host) {
        this.port = port;
        this.host = host;
    }

    public static EchoClient connectTo(int port){
        var localhost = "192.168.242.154";
        return new EchoClient(port, localhost);
    }

    public void run(){
        System.out.printf("Напишите 'bye' чтобы выйти%%n%n");

        try (Socket socket = new Socket(host, port)){
            Scanner scanner = new Scanner(System.in, "UTF-8");
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());

            try (scanner; printWriter){
                String inputMessage = "";
                while (!inputMessage.equalsIgnoreCase("bye")){
                    inputMessage = scanner.nextLine();
                    printWriter.write(inputMessage);
                    printWriter.write(System.lineSeparator());
                    printWriter.flush();

                }
            }
        } catch (NoSuchElementException e){
            System.out.printf("Connection dropped!%n");
        } catch (IOException e){
            System.out.printf("Can't connect to %s:%s!%n", host, port);
            e.printStackTrace();
        }
    }
}
